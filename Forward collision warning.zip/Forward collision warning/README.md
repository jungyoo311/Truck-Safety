Step 1:
git clone https://github.com/ultralytics/yolov5.git
cd yolov5
pip install -r requirements.txt

Step 2:
Download model (best.py): https://drive.google.com/file/d/1_RNsBVPge6aAg_OqobuXFvJeFnIiBTj_/view?usp=sharing
copy fcw_detection.py and best.pt into yolov5 folder
Install moviepy and torch if not already

Step 3:
run script from the yolov5 folder
python fcw_detection.py
